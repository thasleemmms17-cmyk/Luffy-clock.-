# Luffy Clock Android app project

This project contains the Android app source code and the complete clock page with your poster embedded locally.

## Build the installable APK

This environment does not have the Android SDK/Gradle build tools and cannot download them, so it has not produced a compiled APK. Build the APK using Android Studio:

1. On a computer, install Android Studio.
2. Extract this ZIP and open the `LuffyClockAndroid` folder in Android Studio.
3. Allow Gradle sync to complete; install Android SDK Platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When the build completes, click **locate** in the notification. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer `app-debug.apk` to your Android phone and tap it to install. If prompted, allow installation from that file manager.

To install from Android Studio directly, connect your phone with USB debugging enabled and press **Run**.

## App details

- App name: Luffy Clock
- Application ID: `com.thasleem.luffyclock`
- Minimum Android: Android 6.0 (API 23)
- Portrait, immersive full-screen clock
- Local poster and HTML are bundled; no permission to access contacts, location, or files is requested.
